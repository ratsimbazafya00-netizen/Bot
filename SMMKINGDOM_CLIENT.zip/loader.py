import base64
import json
import time
import hashlib
import os
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad

ENC_SECRET = "YTkxZjNjOWUwZjhjMWIyZC4uLg=="

LICENSE_FILE = "license.key"
ENC_FILE = "smmkingdom.enc"

def get_secret():
    return base64.b64decode(ENC_SECRET).decode()

def get_machine_id():
    data = os.popen("uname -a").read() if os.name != "nt" else os.popen("wmic csproduct get uuid").read()
    return hashlib.sha256(data.encode()).hexdigest()

def verify_license():
    if not os.path.exists(LICENSE_FILE):
        print("❌ Licence absente")
        exit()

    lic = json.load(open(LICENSE_FILE))
    if lic["machine_id"] != get_machine_id():
        print("❌ Licence invalide (machine)")
        exit()

    if time.time() > lic["expire"]:
        print("⛔ Licence expirée")
        exit()

def decrypt_and_run():
    key = hashlib.sha256(get_secret().encode()).digest()
    raw = open(ENC_FILE, "rb").read()

    iv = raw[:16]
    data = raw[16:]

    cipher = AES.new(key, AES.MODE_CBC, iv)
    code = unpad(cipher.decrypt(data), AES.block_size)

    exec(code, {"__name__": "__main__"})

if __name__ == "__main__":
    verify_license()
    decrypt_and_run()
