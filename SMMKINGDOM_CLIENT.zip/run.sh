#!/data/data/com.termux/files/usr/bin/bash

clear
echo "======================================="
echo "   SMMKINGDOM TASK • CLIENT OFFICIEL   "
echo "======================================="
echo ""

python loader.py
